# DSTK

A tiny example package.  

```python
import dstk
dstk.hello()