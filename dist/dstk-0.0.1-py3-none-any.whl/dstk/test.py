def hello():
    print('Welcome to DSTK!')