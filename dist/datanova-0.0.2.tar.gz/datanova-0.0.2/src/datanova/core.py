def hello():
    print("Welcome to DataNova!")
