# DataNova

A tiny example package.  

```python
import datanova as dn
dstk.hello()